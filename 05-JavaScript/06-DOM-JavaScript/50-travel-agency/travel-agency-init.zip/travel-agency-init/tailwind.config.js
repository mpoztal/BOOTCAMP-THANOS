module.exports = {
  content: [
    './index.html',
    './src/**/*.js'
  ],
  theme: {
    extend: {}
  },
  plugins: []
}
